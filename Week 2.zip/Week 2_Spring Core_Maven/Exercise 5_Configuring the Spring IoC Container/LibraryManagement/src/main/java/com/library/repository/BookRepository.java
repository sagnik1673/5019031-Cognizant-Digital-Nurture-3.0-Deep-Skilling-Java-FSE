package com.library.repository;

public class BookRepository {
    public void save() {
        System.out.println("Book saved!");
    }
}